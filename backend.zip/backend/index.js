const express = require('express');
const mysql = require('mysql');
const app = express();

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'flashcards_db',
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

app.use(express.json());

app.get('/api/flashcards', (req, res) => {
    const sql = 'SELECT * FROM flashcards';
    db.query(sql, (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

app.post('/api/flashcards', (req, res) => {
    const { question, answer } = req.body;
    const sql = 'INSERT INTO flashcards (question, answer) VALUES (?, ?)';
    db.query(sql, [question, answer], (err, result) => {
        if (err) throw err;
        res.json({ id: result.insertId });
    });
});

// Update and delete routes...

app.listen(5000, () => {
    console.log('Server started on port 5000');
});
